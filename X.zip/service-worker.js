const CACHE_NAME = 'aurora-player-v1';
// قائمة الملفات الأساسية التي يحتاجها التطبيق ليعمل
const urlsToCache = [
  './',
  './Multimedia Player V.6.1.plus.html',
  // يمكنك إضافة مسارات ملفات CSS أو JS أو الأيقونات هنا إذا كانت منفصلة
  './images/icons/icon-192x192.png',
  './images/icons/icon-512x512.png'
];

// عند "تثبيت" عامل الخدمة، قم بتخزين الملفات في الكاش
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache');
        return cache.addAll(urlsToCache);
      })
  );
});

// عند طلب أي ملف (مثل فتح صفحة)، تحقق إذا كان موجودًا في الكاش أولاً
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // إذا كان الملف موجودًا في الكاش، قم بإرجاعه مباشرة
        if (response) {
          return response;
        }
        // إذا لم يكن موجودًا، اطلبه من الشبكة
        return fetch(event.request);
      }
    )
  );
});
